#include "buttons.h"
#include <msp430.h> // definiert Acronyme (Digital I/O Registers)

Buttons Buttons::buttons; // // Singleton Instanz

// Hier muesst ihr selbst Code ergaenzen

