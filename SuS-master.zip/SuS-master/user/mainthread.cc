#include "user/mainthread.h"
#include <msp430.h>
#include "machine/system.h"
#include "machine/lcd.h"

void MainThread::action() {
  while (1) {
    /* Fuer 100ms schlafen legen, um Strom zu sparen */
    this->sleep(100);

    /* Watchdog anstossen */
    watchdog_reset();

    // Hier muesst ihr selbst Code ergaenzen
    //LCD::instance().show_digit(0, 1, true);
    //LCD::instance().show_digit(2, 2, true);
    LCD::instance().show_char('k',1,false);
    LCD::instance().show_char('e',2,false);
    LCD::instance().show_char('v',3,false);
    LCD::instance().show_char('i',4,false);
    LCD::instance().show_char('n',5,false);
    LCD::instance().show_number(1234,true);


  }
  // Achtung: Die action()-Methode darf nicht zurueckkehren,
  //          daher die Endlosschleife!
}
