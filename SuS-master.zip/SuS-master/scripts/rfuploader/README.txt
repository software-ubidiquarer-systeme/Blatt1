In diesem Verzeichnis liegt eine angepasste Version des
Chronos Control Centers, welches auf die Funk-Flashfunktion
reduziert wurde. Wenn ein Kommandozeilen-Parameter angegeben wurde,
verwendet es diesen als Vorgabe fuer den Dateinamen.

Funktion oder Nichtfunktion des RF-Bootloaders hat gewisse Ähnlichkeiten
mit Voodoo - mal funktioniert es besser, mal schlechter und darüber wie
man die Funktion zuverlässiger hinbekommt hat jeder eigene Ansichten.

Dinge, die evtl. hilfreich sein können:
- Nach dem Klick auf den "Upload"-Button warten, bis der Fortschrittsbalken
  zurückgesetzt wurde
- Flashvorgang mit Cancel abbrechen und neu starten
- Flash-Tool beenden, Stick abziehen, Stick einstecken, Flashtool wieder starten
- Den RF-Bootloader auf der Uhr aus einem Zustand heraus auslösen, in dem
  möglichst wenig Strom verbraucht wurde - wenn die Batterie beim Flashen
  aufgibt wird oft der Schraubendreher notwendig.
- ggfs. andere gerade funkende Uhren ruhig stellen oder weit genug entfernen
