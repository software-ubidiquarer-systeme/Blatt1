#!/bin/bash

cd `dirname $0`
exec ./rfuploader.tcl $1

