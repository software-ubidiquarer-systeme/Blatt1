// This file is to help eclipse with syntax highlighting...
#ifndef __sus_msp430_h_
#define __sus_msp430_h_

#ifndef MAKEFILE_COMPILE
#define __CC430F6137__
#endif
// Path may need to be changed to actual path.
// Maybe #include_next might work...
#include </usr/msp430/include/msp430.h>

#endif

