#include "syscall/guarded_rtc.h"

Guarded_RTC Guarded_RTC::rtc;

